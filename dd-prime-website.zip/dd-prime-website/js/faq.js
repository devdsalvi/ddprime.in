/* ==========================================================================
   DD PRIME SOLUTION — FAQ.JS
   Handles the FAQ accordion open/close behaviour.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', function () {

  var faqItems = document.querySelectorAll('.faq-item');

  faqItems.forEach(function (item) {
    var question = item.querySelector('.faq-question');
    var answer = item.querySelector('.faq-answer');
    if (!question || !answer) return;

    question.addEventListener('click', function () {
      var isOpen = item.classList.contains('open');

      /* Close all other open FAQ items so only one is open at a time */
      faqItems.forEach(function (otherItem) {
        otherItem.classList.remove('open');
        var otherQuestion = otherItem.querySelector('.faq-question');
        if (otherQuestion) otherQuestion.setAttribute('aria-expanded', 'false');
      });

      /* Toggle the clicked item */
      if (!isOpen) {
        item.classList.add('open');
        question.setAttribute('aria-expanded', 'true');
      }
    });
  });

});
