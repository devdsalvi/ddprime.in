/* ==========================================================================
   DD PRIME SOLUTION — FORM-VALIDATION.JS
   Frontend-only validation for the contact form.

   IMPORTANT: This validates fields in the browser only. No data is actually
   sent anywhere. To receive real submissions you must connect this form to
   a backend or a form service (for example: Formspree, Getform, EmailJS,
   Google Apps Script, or your own server endpoint) using the form's
   "action" attribute or a fetch()/XHR call inside the submit handler below.
   ========================================================================== */

document.addEventListener('DOMContentLoaded', function () {

  var form = document.getElementById('contact-form');
  if (!form) return;

  var successBox = document.getElementById('form-success');

  var validators = {
    'full-name': function (value) {
      return value.trim().length >= 3 ? '' : 'Please enter your full name (at least 3 characters).';
    },
    'phone': function (value) {
      var digitsOnly = value.replace(/\D/g, '');
      return digitsOnly.length >= 10 ? '' : 'Please enter a valid phone number (at least 10 digits).';
    },
    'email': function (value) {
      var pattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      return pattern.test(value.trim()) ? '' : 'Please enter a valid email address.';
    },
    'service': function (value) {
      return value !== '' ? '' : 'Please select a service.';
    },
    'message': function (value) {
      return value.trim().length >= 10 ? '' : 'Please enter a short message (at least 10 characters).';
    }
  };

  function showError(fieldId, message) {
    var group = document.getElementById('group-' + fieldId);
    var errorEl = document.getElementById('error-' + fieldId);
    if (group) group.classList.add('invalid');
    if (errorEl) errorEl.textContent = message;
  }

  function clearError(fieldId) {
    var group = document.getElementById('group-' + fieldId);
    if (group) group.classList.remove('invalid');
  }

  function validateField(fieldId) {
    var field = document.getElementById(fieldId);
    if (!field) return true;
    var validate = validators[fieldId];
    if (!validate) return true;

    var errorMessage = validate(field.value);
    if (errorMessage) {
      showError(fieldId, errorMessage);
      return false;
    } else {
      clearError(fieldId);
      return true;
    }
  }

  /* Live validation as the user leaves each field */
  Object.keys(validators).forEach(function (fieldId) {
    var field = document.getElementById(fieldId);
    if (field) {
      field.addEventListener('blur', function () { validateField(fieldId); });
      field.addEventListener('input', function () {
        var group = document.getElementById('group-' + fieldId);
        if (group && group.classList.contains('invalid')) {
          validateField(fieldId);
        }
      });
    }
  });

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    var isFormValid = true;
    Object.keys(validators).forEach(function (fieldId) {
      var fieldIsValid = validateField(fieldId);
      if (!fieldIsValid) isFormValid = false;
    });

    if (!isFormValid) {
      if (successBox) successBox.classList.remove('show');
      var firstInvalid = form.querySelector('.invalid input, .invalid select, .invalid textarea');
      if (firstInvalid) firstInvalid.focus();
      return;
    }

    /* Prevent empty / bogus submissions, then show the success message.
       Replace this block with a real fetch() call to your backend
       or form service to actually receive submissions. */
    if (successBox) {
      successBox.classList.add('show');
      successBox.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }
    form.reset();
  });

});
